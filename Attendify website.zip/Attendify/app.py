from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Database setup
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///attendance.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User and Attendance models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False, unique=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    role = db.Column(db.String(20), nullable=False)  # 'teacher' or 'parent'
    password_hash = db.Column(db.String(100), nullable=False)  # Hashed password

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(10), nullable=False)
    division = db.Column(db.String(5), nullable=False)  # To store division info (e.g., 'A', 'B', ...)

# Home Route
@app.route('/')
def home():
    return render_template('index.html')

# Mark Attendance Page - Display Divisions
@app.route('/mark-attendance')
def mark_attendance():
    divisions = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']  # List of 10 divisions
    return render_template('mark_attendance.html', divisions=divisions)
@app.route('/attendance/<division>')
def division_attendance(division):
    return render_template(f'attendance_{division}.html')


# View Attendance Route (no login required)
@app.route('/view-attendance')
def view_attendance():
    attendance_records = Attendance.query.all()
    return render_template('view_attendance.html', attendance_records=attendance_records)

# Register Route for New Users
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        role = request.form['role']  # Choose either 'teacher' or 'parent'
        password = request.form['password']

        if User.query.filter_by(email=email).first():
            flash("Email already exists. Please use a different email.")
            return redirect(url_for('register'))

        new_user = User(username=username, email=email, role=role)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        
        flash("Registration successful. Please log in.")
        return redirect(url_for('login'))

    return render_template('register.html')

# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['role'] = user.role
            session['username'] = user.username
            flash(f"Logged in as {user.username}")
            return redirect(url_for('home'))
        else:
            flash("Login failed. Check your email and password.")
    return render_template('login.html')

# Logout Route
@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.")
    return redirect(url_for('home'))

# Database initialization
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True) 